import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentApplicationComponent } from './recent-application.component';

describe('RecentApplicationComponent', () => {
  let component: RecentApplicationComponent;
  let fixture: ComponentFixture<RecentApplicationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RecentApplicationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RecentApplicationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
