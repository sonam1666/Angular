import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recent-application',
  templateUrl: './recent-application.component.html',
  styleUrls: ['./recent-application.component.css']
})
export class RecentApplicationComponent implements OnInit {
  headers = ["Sr.no", "Name", "Title", "Job Name","Category","Location"];
  rows = [
    {
      "Sr.no" : "01",
      "Name" : "Suresh Verma",
      "Title" : "UI Designer",
      "Job Name" : "User Experience Designer",
      "Category" : "Marketing",
      "Location" : "Pune"
    },
    {
      "Sr.no" : "02",
      "Name" : "Suresh Verma",
      "Title" : "UI Designer",
      "Job Name" : "User Experience Designer",
      "Category" : "Marketing",
      "Location" : "Mahabaleshwar"
    },
    {
      "Sr.no" : "03",
      "Name" : "Suresh Verma",
      "Title" : "UI Designer",
      "Job Name" : "User Experience Designer",
      "Category" : "Marketing",
      "Location" : "Pune"
    },
    {
      "Sr.no" : "04",
      "Name" : "Suresh Verma",
      "Title" : "UI Designer",
      "Job Name" : "User Experience Designer",
      "Category" : "Marketing",
      "Location" : "Mahabaleshwar"
    },
    {
      "Sr.no" : "05",
      "Name" : "Suresh Verma",
      "Title" : "UI Designer",
      "Job Name" : "User Experience Designer",
      "Category" : "Marketing",
      "Location" : "Pune"
    }
  ]

  constructor() { }

  ngOnInit(): void {
  }

}
