import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CastIndiaBlogsComponent } from './cast-india-blogs.component';

describe('CastIndiaBlogsComponent', () => {
  let component: CastIndiaBlogsComponent;
  let fixture: ComponentFixture<CastIndiaBlogsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CastIndiaBlogsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CastIndiaBlogsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
