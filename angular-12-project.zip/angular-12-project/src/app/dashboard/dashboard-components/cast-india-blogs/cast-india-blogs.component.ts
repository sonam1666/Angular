import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cast-india-blogs',
  templateUrl: './cast-india-blogs.component.html',
  styleUrls: ['./cast-india-blogs.component.css']
})
export class CastIndiaBlogsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
