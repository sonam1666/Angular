import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberofprojectsComponent } from './numberofprojects.component';

describe('NumberofprojectsComponent', () => {
  let component: NumberofprojectsComponent;
  let fixture: ComponentFixture<NumberofprojectsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NumberofprojectsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberofprojectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
