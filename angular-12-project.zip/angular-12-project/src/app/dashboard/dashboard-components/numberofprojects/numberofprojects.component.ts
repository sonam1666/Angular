import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-numberofprojects',
  templateUrl: './numberofprojects.component.html',
  styleUrls: ['./numberofprojects.component.css']
})
export class NumberofprojectsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
