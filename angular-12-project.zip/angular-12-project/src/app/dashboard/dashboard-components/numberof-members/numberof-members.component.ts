import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-numberof-members',
  templateUrl: './numberof-members.component.html',
  styleUrls: ['./numberof-members.component.css']
})
export class NumberofMembersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
