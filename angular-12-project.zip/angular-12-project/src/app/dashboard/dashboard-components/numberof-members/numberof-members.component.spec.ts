import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NumberofMembersComponent } from './numberof-members.component';

describe('NumberofMembersComponent', () => {
  let component: NumberofMembersComponent;
  let fixture: ComponentFixture<NumberofMembersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NumberofMembersComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NumberofMembersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
