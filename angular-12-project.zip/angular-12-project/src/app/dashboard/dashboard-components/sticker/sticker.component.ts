import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sticker',
  templateUrl: './sticker.component.html',
  styleUrls: ['./sticker.component.css']
})
export class StickerComponent implements OnInit {
  headers = ["Job Name", "Category", "Location", "Applications"];
  rows = [
    {
      "Job Name" : "User Interface Designer",
      "Category" : "Marketing",
      "Location" : "Pune",
      "Applications" : "View"
    },
    {
      "Job Name" : "User Interface Designer",
      "Category" : "Marketing",
      "Location" : "Pune",
      "Applications" : "View"
    },
    {
      "Job Name" : "User Interface Designer",
      "Category" : "Marketing",
      "Location" : "Pune",
      "Applications" : "View"
    },
    {
      "Job Name" : "User Interface Designer",
      "Category" : "Marketing",
      "Location" : "Pune",
      "Applications" : "View"
    },
    {
      "Job Name" : "User Interface Designer",
      "Category" : "Marketing",
      "Location" : "Pune",
      "Applications" : "View"
    }
  ]
  constructor() { }

  ngOnInit(): void {
  }

}
